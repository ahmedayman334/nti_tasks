sealed class TextState {}

final class TextInitial extends TextState {}

final class AlamdulAlah extends TextState {}

final class AlahAkbar extends TextState {}

final class SobhanAlah extends TextState {}

final class LaElahElaAlah extends TextState {}

final class LaQoutaElaBAlah extends TextState {}
